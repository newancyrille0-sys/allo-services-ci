import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Search, User, Menu, X, LogOut, LayoutDashboard, ShieldCheck, Camera } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { auth } from '../firebase';
import { signOut } from 'firebase/auth';
import { cn } from '../lib/utils';

export default function Navbar() {
  const { user, profile } = useAuth();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const navigate = useNavigate();

  const handleLogout = async () => {
    await signOut(auth);
    navigate('/');
  };

  return (
    <nav className="sticky top-0 z-50 bg-white/90 backdrop-blur-md border-b border-gray-100">
      <div className="max-w-7xl mx-auto px-4 h-20 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-3">
          <img 
            src="https://storage.googleapis.com/gpt-engineer-file-uploads/UwYypcGML3bDONL5eWcQAcyQekD3/07b926e2-bd04-4363-9a73-2f5c4edfcea9?Expires=1774432588&GoogleAccessId=go-api-on-aws%40gpt-engineer-390607.iam.gserviceaccount.com&Signature=Wt1x%2F%2BUWWC58Ngw7aCBIvWV1gzyqmGV5R3aIdjL%2B%2FokkDYul%2BP6kP8gOcgCcLIut%2F4Kd284ne3ciqDacwTR1qGVhVHIN4Jd9XW5gLUW0ZTme5e4SjsXSRyo%2Fi4KGt%2FYt%2BS8L0GvyJWNZ%2Fb4LSsVnBne79%2FwC%2BRETz6RmInxXuqygKh%2BJpsIAfsXBKcBQ8NPXoFQQc%2BxTv4IAhwgeQwXCvjaaOyHkRhoAyeBa9MOyAjbJDGBFcQGf2xysUIfIQ1HAWNZ321142Ql50h1WgRQd30%2BUcKebvH6JdMQCoQZIHBTxvG6%2FHFLZOWGCGqgmN%2BmUaazYrJQNa26sCncVCbydPg%3D%3D" 
            alt="Allo Services CI" 
            className="h-14 w-auto"
            referrerPolicy="no-referrer"
          />
        </Link>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center gap-8">
          <Link to="/" className="text-gray-600 hover:text-brand-blue font-semibold transition-colors">Accueil</Link>
          <Link to="/search" className="text-gray-600 hover:text-brand-blue font-semibold transition-colors">Services</Link>
          <Link to="/feed" className="text-gray-600 hover:text-brand-blue font-semibold transition-colors flex items-center gap-1">
            <Camera className="w-4 h-4" />
            Réalisations
          </Link>
          
          {user ? (
            <div className="flex items-center gap-4">
              <Link 
                to="/dashboard" 
                className="flex items-center gap-2 bg-gray-50 px-4 py-2 rounded-full hover:bg-gray-100 transition-colors border border-gray-100"
              >
                {profile?.photoURL ? (
                  <img src={profile.photoURL} alt="" className="w-6 h-6 rounded-full object-cover" />
                ) : (
                  <User className="w-4 h-4 text-gray-600" />
                )}
                <span className="text-sm font-bold text-gray-900">{profile?.displayName || 'Mon Compte'}</span>
              </Link>
              {profile?.role === 'admin' && (
                <Link to="/admin" className="p-2 text-gray-400 hover:text-brand-blue transition-colors">
                  <ShieldCheck className="w-5 h-5" />
                </Link>
              ) }
              <button 
                onClick={handleLogout}
                className="p-2 text-gray-400 hover:text-red-500 transition-colors"
              >
                <LogOut className="w-5 h-5" />
              </button>
            </div>
          ) : (
            <div className="flex items-center gap-4">
              <Link 
                to="/auth" 
                className="text-gray-900 font-bold hover:text-brand-blue transition-colors"
              >
                Connexion
              </Link>
              <Link 
                to="/auth?mode=signup" 
                className="bg-brand-blue text-white px-8 py-3 rounded-full font-bold hover:bg-blue-700 transition-all shadow-lg shadow-blue-200 active:scale-95"
              >
                Inscription
              </Link>
            </div>
          )}
        </div>

        {/* Mobile Menu Toggle */}
        <button 
          className="md:hidden p-2 text-gray-600"
          onClick={() => setIsMenuOpen(!isMenuOpen)}
        >
          {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>

      {/* Mobile Menu */}
      <div className={cn(
        "md:hidden absolute top-20 left-0 w-full bg-white border-b border-gray-100 transition-all duration-300 overflow-hidden shadow-xl",
        isMenuOpen ? "max-h-96 opacity-100" : "max-h-0 opacity-0 pointer-events-none"
      )}>
        <div className="p-6 flex flex-col gap-6">
          <Link to="/" onClick={() => setIsMenuOpen(false)} className="text-lg font-bold text-gray-900">Accueil</Link>
          <Link to="/search" onClick={() => setIsMenuOpen(false)} className="text-lg font-bold text-gray-900">Services</Link>
          <Link to="/feed" onClick={() => setIsMenuOpen(false)} className="text-lg font-bold text-gray-900">Réalisations</Link>
          {user ? (
            <>
              <Link to="/dashboard" onClick={() => setIsMenuOpen(false)} className="text-lg font-bold text-gray-900">Mon Tableau de Bord</Link>
              {profile?.role === 'admin' && (
                <Link to="/admin" onClick={() => setIsMenuOpen(false)} className="text-lg font-bold text-gray-900">Admin</Link>
              )}
              <button 
                onClick={() => { handleLogout(); setIsMenuOpen(false); }}
                className="text-lg font-bold text-red-500 text-left"
              >
                Déconnexion
              </button>
            </>
          ) : (
            <div className="flex flex-col gap-4 pt-4 border-t border-gray-50">
              <Link 
                to="/auth" 
                onClick={() => setIsMenuOpen(false)}
                className="text-lg font-bold text-gray-900 text-center"
              >
                Connexion
              </Link>
              <Link 
                to="/auth?mode=signup" 
                onClick={() => setIsMenuOpen(false)}
                className="bg-brand-blue text-white px-6 py-4 rounded-2xl font-bold text-center shadow-lg shadow-blue-100"
              >
                Inscription
              </Link>
            </div>
          )}
        </div>
      </div>
    </nav>
  );
}
