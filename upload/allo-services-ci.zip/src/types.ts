import { Timestamp } from 'firebase/firestore';

export type UserRole = 'client' | 'provider' | 'admin';
export type SubscriptionStatus = 'free' | 'monthly' | 'premium';

export interface UserProfile {
  uid: string;
  displayName: string;
  email: string;
  phoneNumber?: string;
  photoURL?: string;
  role: UserRole;
  isVerified?: boolean;
  isPremium?: boolean;
  subscriptionStatus?: SubscriptionStatus;
  city?: string;
  category?: string;
  description?: string;
  trustScore?: number;
  createdAt: Timestamp;
  paymentProof?: string;
  idDocument?: string;
  selfieVideo?: string;
  isPremiumPending?: boolean;
}

export interface PostMedia {
  url: string;
  type: 'image' | 'video';
}

export interface Post {
  id: string;
  providerId: string;
  caption?: string;
  media: PostMedia[];
  createdAt: Timestamp;
  views?: number;
  likes?: number;
}

export interface Booking {
  id: string;
  clientId: string;
  providerId: string;
  date: string; // YYYY-MM-DD
  time?: string;
  message?: string;
  status: 'pending' | 'confirmed' | 'completed' | 'cancelled';
  createdAt: Timestamp;
}

export interface Review {
  id: string;
  clientId: string;
  providerId: string;
  rating: number;
  comment?: string;
  createdAt: Timestamp;
}
