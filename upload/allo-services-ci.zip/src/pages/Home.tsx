import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Search, MapPin, Star, ShieldCheck, ArrowRight, Camera, Users, CheckCircle2 } from 'lucide-react';
import { motion } from 'framer-motion';
import { CATEGORIES, CITIES, cn } from '../lib/utils';

export default function Home() {
  const [search, setSearch] = useState('');
  const [city, setCity] = useState('');
  const navigate = useNavigate();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    navigate(`/search?q=${search}&city=${city}`);
  };

  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="relative pt-20 pb-32 px-4 overflow-hidden">
        <div className="absolute inset-0 -z-10 bg-[radial-gradient(45%_45%_at_50%_50%,rgba(0,102,255,0.05)_0%,rgba(255,255,255,0)_100%)]" />
        
        <div className="max-w-5xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <span className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-blue-50 text-brand-blue text-sm font-bold mb-6 border border-blue-100">
              <Star className="w-4 h-4 fill-brand-blue" />
              La Marketplace #1 en Côte d'Ivoire
            </span>
            <h1 className="text-5xl md:text-7xl font-extrabold text-gray-900 tracking-tight mb-8 leading-[1.1]">
              Trouvez le <span className="text-brand-blue">prestataire</span> idéal en un clic.
            </h1>
            <p className="text-xl text-gray-600 mb-12 max-w-2xl mx-auto leading-relaxed font-medium">
              Plomberie, électricité, ménage ou coiffure... Accédez à des milliers de professionnels vérifiés partout en Côte d'Ivoire.
            </p>
          </motion.div>

          {/* Search Bar */}
          <motion.form 
            onSubmit={handleSearch}
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2, duration: 0.5 }}
            className="bg-white p-2 rounded-3xl shadow-2xl shadow-blue-100/50 border border-gray-100 flex flex-col md:flex-row gap-2 max-w-4xl mx-auto"
          >
            <div className="flex-grow flex items-center px-4 gap-3 border-b md:border-b-0 md:border-r border-gray-100 py-3">
              <Search className="w-5 h-5 text-gray-400" />
              <input 
                type="text" 
                placeholder="Quel service cherchez-vous ?" 
                className="w-full bg-transparent outline-none text-gray-900 font-bold placeholder:text-gray-400"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </div>
            <div className="flex-grow flex items-center px-4 gap-3 py-3">
              <MapPin className="w-5 h-5 text-gray-400" />
              <select 
                className="w-full bg-transparent outline-none text-gray-900 font-bold appearance-none cursor-pointer"
                value={city}
                onChange={(e) => setCity(e.target.value)}
              >
                <option value="">Toute la Côte d'Ivoire</option>
                {CITIES.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <button 
              type="submit"
              className="bg-brand-blue text-white px-10 py-4 rounded-2xl font-bold hover:bg-blue-700 transition-all flex items-center justify-center gap-2 shadow-xl shadow-blue-200 active:scale-95"
            >
              Rechercher
            </button>
          </motion.form>
        </div>
      </section>

      {/* Categories Grid */}
      <section className="py-20 px-4 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-end justify-between mb-12">
            <div>
              <h2 className="text-4xl font-extrabold text-gray-900 mb-2 tracking-tight">Parcourir par catégorie</h2>
              <p className="text-gray-500 font-medium text-lg">Découvrez nos services les plus populaires</p>
            </div>
            <Link to="/search" className="text-brand-blue font-bold flex items-center gap-1 hover:gap-2 transition-all text-lg">
              Voir tout <ArrowRight className="w-5 h-5" />
            </Link>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-6">
            {CATEGORIES.map((cat) => (
              <Link 
                key={cat.name} 
                to={`/search?q=${cat.name}`}
                className="group p-8 rounded-[2.5rem] bg-gray-50 border border-transparent hover:border-blue-200 hover:bg-blue-50/30 transition-all text-center"
              >
                <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-sm group-hover:scale-110 transition-transform">
                  <span className="text-3xl">
                    {cat.icon}
                  </span>
                </div>
                <span className="font-bold text-gray-900 text-lg">{cat.name}</span>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Social Module Preview */}
      <section className="py-24 px-4 bg-gray-50">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-2 gap-20 items-center">
            <div className="relative">
              <div className="grid grid-cols-2 gap-6">
                <div className="space-y-6">
                  <img src="https://picsum.photos/seed/plumber/400/500" alt="" className="rounded-[2.5rem] shadow-2xl" referrerPolicy="no-referrer" />
                  <img src="https://picsum.photos/seed/electrician/400/300" alt="" className="rounded-[2.5rem] shadow-2xl" referrerPolicy="no-referrer" />
                </div>
                <div className="space-y-6 pt-16">
                  <img src="https://picsum.photos/seed/painter/400/300" alt="" className="rounded-[2.5rem] shadow-2xl" referrerPolicy="no-referrer" />
                  <img src="https://picsum.photos/seed/cleaner/400/500" alt="" className="rounded-[2.5rem] shadow-2xl" referrerPolicy="no-referrer" />
                </div>
              </div>
              <div className="absolute -bottom-10 -right-10 bg-white p-8 rounded-[2.5rem] shadow-2xl border border-gray-100 flex items-center gap-6">
                <div className="w-16 h-16 bg-green-100 text-green-600 rounded-full flex items-center justify-center">
                  <Camera className="w-8 h-8" />
                </div>
                <div>
                  <p className="font-extrabold text-gray-900 text-xl">+500 Posts/jour</p>
                  <p className="text-gray-500 font-medium">Réalisations en direct</p>
                </div>
              </div>
            </div>
            
            <div className="space-y-10">
              <h2 className="text-5xl font-extrabold text-gray-900 leading-tight tracking-tight">
                Plus qu'une marketplace, un <span className="text-brand-blue">réseau social</span> de confiance.
              </h2>
              <p className="text-xl text-gray-600 leading-relaxed font-medium">
                Ne vous fiez pas seulement aux mots. Visualisez le travail des prestataires à travers leurs publications photos et vidéos. Un portfolio dynamique pour une transparence totale.
              </p>
              <ul className="space-y-6">
                {[
                  "Photos & Vidéos des réalisations",
                  "Feed dynamique type Instagram",
                  "Commentaires et avis vérifiés",
                  "Contact direct via WhatsApp"
                ].map(item => (
                  <li key={item} className="flex items-center gap-4 text-gray-800 font-bold text-lg">
                    <CheckCircle2 className="w-7 h-7 text-brand-blue" />
                    {item}
                  </li>
                ))}
              </ul>
              <Link 
                to="/feed" 
                className="inline-flex items-center gap-3 bg-gray-900 text-white px-10 py-5 rounded-2xl font-bold hover:bg-black transition-all shadow-2xl active:scale-95 text-lg"
              >
                Découvrir le feed <ArrowRight className="w-6 h-6" />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Trust Section */}
      <section className="py-24 px-4 bg-white border-y border-gray-100">
        <div className="max-w-7xl mx-auto text-center">
          <h2 className="text-4xl font-extrabold text-gray-900 mb-20 tracking-tight">Pourquoi nous faire confiance ?</h2>
          <div className="grid md:grid-cols-3 gap-16">
            <div className="space-y-6">
              <div className="w-20 h-20 bg-blue-50 text-brand-blue rounded-3xl flex items-center justify-center mx-auto mb-8 shadow-sm">
                <ShieldCheck className="w-10 h-10" />
              </div>
              <h3 className="text-2xl font-extrabold text-gray-900">Profils Vérifiés</h3>
              <p className="text-gray-500 font-medium text-lg leading-relaxed">Chaque prestataire passe par une vérification d'identité stricte (CNI + Vidéo selfie).</p>
            </div>
            <div className="space-y-6">
              <div className="w-20 h-20 bg-orange-50 text-brand-orange rounded-3xl flex items-center justify-center mx-auto mb-8 shadow-sm">
                <Users className="w-10 h-10" />
              </div>
              <h3 className="text-2xl font-extrabold text-gray-900">Score de Confiance</h3>
              <p className="text-gray-500 font-medium text-lg leading-relaxed">Un système de notation basé sur les avis clients et la qualité des prestations.</p>
            </div>
            <div className="space-y-6">
              <div className="w-20 h-20 bg-green-50 text-green-600 rounded-3xl flex items-center justify-center mx-auto mb-8 shadow-sm">
                <CheckCircle2 className="w-10 h-10" />
              </div>
              <h3 className="text-2xl font-extrabold text-gray-900">Paiement Sécurisé</h3>
              <p className="text-gray-500 font-medium text-lg leading-relaxed">Le paiement se fait après la prestation. Pas de mauvaises surprises.</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 px-4">
        <div className="max-w-5xl mx-auto bg-brand-blue rounded-[4rem] p-16 md:p-24 text-center text-white relative overflow-hidden shadow-2xl shadow-blue-200">
          <div className="absolute top-0 right-0 w-80 h-80 bg-white/10 rounded-full -mr-40 -mt-40 blur-3xl" />
          <div className="absolute bottom-0 left-0 w-80 h-80 bg-black/10 rounded-full -ml-40 -mb-40 blur-3xl" />
          
          <h2 className="text-5xl md:text-6xl font-extrabold mb-10 relative z-10 tracking-tight">Vous êtes un professionnel ?</h2>
          <p className="text-2xl text-blue-50 mb-14 max-w-2xl mx-auto relative z-10 font-medium opacity-90">
            Rejoignez Allo Services CI et boostez votre activité dès aujourd'hui. Publiez vos travaux et trouvez de nouveaux clients.
          </p>
          <div className="flex flex-col sm:flex-row gap-6 justify-center relative z-10">
            <Link 
              to="/auth?role=provider" 
              className="bg-white text-brand-blue px-12 py-6 rounded-[2rem] font-extrabold hover:bg-blue-50 transition-all shadow-2xl active:scale-95 text-xl"
            >
              Devenir Prestataire
            </Link>
            <Link 
              to="/search" 
              className="bg-blue-700 text-white px-12 py-6 rounded-[2rem] font-extrabold hover:bg-blue-800 transition-all active:scale-95 border border-blue-500/30 text-xl"
            >
              Trouver un service
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
