import React, { useState, useEffect } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { collection, query, where, getDocs, orderBy } from 'firebase/firestore';
import { db } from '../firebase';
import { UserProfile } from '../types';
import { Search as SearchIcon, MapPin, Star, ShieldCheck, Filter, SlidersHorizontal, Loader2, Crown, CheckCircle2, ChevronRight } from 'lucide-react';
import { CATEGORIES, CITIES, cn, getThemeColors, getSubscriptionPriority } from '../lib/utils';
import { motion } from 'framer-motion';

export default function Search() {
  const [searchParams, setSearchParams] = useSearchParams();
  const queryParam = searchParams.get('q') || '';
  const cityParam = searchParams.get('city') || '';
  const categoryParam = searchParams.get('category') || '';

  const [providers, setProviders] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({
    q: queryParam,
    city: cityParam,
    category: categoryParam,
    verified: false,
  });

  useEffect(() => {
    fetchProviders();
  }, [queryParam, cityParam, categoryParam]);

  const fetchProviders = async () => {
    setLoading(true);
    try {
      let q = query(collection(db, 'users'), where('role', '==', 'provider'));

      if (filters.city) {
        q = query(q, where('city', '==', filters.city));
      }
      if (filters.category) {
        q = query(q, where('category', '==', filters.category));
      }

      const snapshot = await getDocs(q);
      let results = snapshot.docs.map(doc => doc.data() as UserProfile);

      // Client-side text search for name/description/category
      if (filters.q) {
        const searchLower = filters.q.toLowerCase();
        results = results.filter(p => 
          p.displayName?.toLowerCase().includes(searchLower) ||
          p.category?.toLowerCase().includes(searchLower) ||
          p.description?.toLowerCase().includes(searchLower)
        );
      }

      if (filters.verified) {
        results = results.filter(p => p.isVerified);
      }

      // Sort by subscription priority
      results.sort((a, b) => {
        const priorityA = getSubscriptionPriority(a.subscriptionStatus);
        const priorityB = getSubscriptionPriority(b.subscriptionStatus);
        if (priorityA !== priorityB) return priorityB - priorityA;
        return (b.trustScore || 0) - (a.trustScore || 0);
      });

      setProviders(results);
    } catch (error) {
      console.error("Error fetching providers:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleFilterChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target as HTMLInputElement;
    const val = type === 'checkbox' ? (e.target as HTMLInputElement).checked : value;
    setFilters(prev => ({ ...prev, [name]: val }));
  };

  const applyFilters = (e: React.FormEvent) => {
    e.preventDefault();
    setSearchParams({ q: filters.q, city: filters.city, category: filters.category });
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row gap-8">
        {/* Sidebar Filters */}
        <aside className="w-full md:w-72 shrink-0">
          <div className="bg-white p-6 rounded-[2rem] shadow-xl shadow-gray-100 border border-gray-100 sticky top-24">
            <div className="flex items-center gap-2 mb-6">
              <SlidersHorizontal className="w-5 h-5 text-brand-blue" />
              <h2 className="font-bold text-xl text-gray-900">Filtres</h2>
            </div>

            <form onSubmit={applyFilters} className="space-y-6">
              <div className="space-y-2">
                <label className="text-sm font-bold text-gray-700">Recherche</label>
                <div className="relative">
                  <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <input 
                    type="text" 
                    name="q"
                    placeholder="Ex: Plombier..."
                    className="w-full pl-10 pr-4 py-3 bg-gray-50 border border-gray-100 rounded-xl outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-brand-blue transition-all font-bold"
                    value={filters.q}
                    onChange={handleFilterChange}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-bold text-gray-700">Ville</label>
                <select 
                  name="city"
                  className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-brand-blue transition-all appearance-none cursor-pointer font-bold"
                  value={filters.city}
                  onChange={handleFilterChange}
                >
                  <option value="">Toutes les villes</option>
                  {CITIES.map(c => <option key={c} value={c}>{c}</option>)}
                </select>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-bold text-gray-700">Catégorie</label>
                <select 
                  name="category"
                  className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-brand-blue transition-all appearance-none cursor-pointer font-bold"
                  value={filters.category}
                  onChange={handleFilterChange}
                >
                  <option value="">Toutes les catégories</option>
                  {CATEGORIES.map(c => <option key={c.name} value={c.name}>{c.name}</option>)}
                </select>
              </div>

              <label className="flex items-center gap-3 cursor-pointer group">
                <div className="relative flex items-center">
                  <input 
                    type="checkbox" 
                    name="verified"
                    className="peer sr-only"
                    checked={filters.verified}
                    onChange={handleFilterChange}
                  />
                  <div className="w-10 h-6 bg-gray-200 rounded-full peer peer-checked:bg-brand-blue transition-all after:content-[''] after:absolute after:top-1 after:left-1 after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:after:translate-x-4" />
                </div>
                <span className="text-sm font-bold text-gray-700 group-hover:text-brand-blue transition-colors">Vérifiés uniquement</span>
              </label>

              <button 
                type="submit"
                className="w-full bg-gray-900 text-white py-4 rounded-2xl font-bold hover:bg-black transition-all active:scale-95 shadow-lg shadow-gray-200"
              >
                Appliquer
              </button>
            </form>
          </div>
        </aside>

        {/* Results Grid */}
        <div className="flex-grow">
          <div className="flex items-center justify-between mb-8">
            <h1 className="text-3xl font-extrabold text-gray-900 tracking-tight">
              {loading ? 'Recherche...' : `${providers.length} prestataires trouvés`}
            </h1>
          </div>

          {loading ? (
            <div className="flex flex-col items-center justify-center py-20 gap-4">
              <Loader2 className="w-10 h-10 text-brand-blue animate-spin" />
              <p className="text-gray-500 font-bold">Nous trouvons les meilleurs experts pour vous...</p>
            </div>
          ) : providers.length > 0 ? (
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
              {providers.map((provider, i) => {
                const theme = getThemeColors(provider.subscriptionStatus);
                return (
                  <motion.div
                    key={provider.uid}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.05 }}
                  >
                    <Link 
                      to={`/provider/${provider.uid}`}
                      className={cn(
                        "group block bg-white rounded-[2.5rem] overflow-hidden hover:shadow-2xl transition-all hover:-translate-y-1 border border-gray-100",
                        provider.subscriptionStatus === 'premium' ? "ring-2 ring-orange-400 ring-offset-2 shadow-xl shadow-orange-100" : 
                        provider.subscriptionStatus === 'monthly' ? "ring-2 ring-emerald-400 ring-offset-2 shadow-lg shadow-emerald-50" : 
                        ""
                      )}
                    >
                      <div className="relative h-56 bg-gray-100">
                        <img 
                          src={provider.photoURL || `https://picsum.photos/seed/${provider.uid}/400/300`} 
                          alt={provider.displayName}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                          referrerPolicy="no-referrer"
                        />
                        {provider.subscriptionStatus === 'premium' && (
                          <div className="absolute top-4 right-4 bg-orange-500 text-white px-4 py-1.5 rounded-full text-[10px] font-black shadow-lg flex items-center gap-1.5">
                            <Crown className="w-3.5 h-3.5" /> PREMIUM+
                          </div>
                        )}
                        {provider.subscriptionStatus === 'monthly' && (
                          <div className="absolute top-4 right-4 bg-emerald-500 text-white px-4 py-1.5 rounded-full text-[10px] font-black shadow-lg flex items-center gap-1.5">
                            <CheckCircle2 className="w-3.5 h-3.5" /> VÉRIFIÉ
                          </div>
                        )}
                      </div>
                      <div className="p-8">
                        <div className="flex items-start justify-between mb-4">
                          <div>
                            <h3 className="font-extrabold text-xl text-gray-900 flex items-center gap-2">
                              {provider.displayName}
                              {provider.isVerified && <ShieldCheck className="w-5 h-5 text-brand-blue fill-blue-50" />}
                            </h3>
                            <p className="text-sm font-black uppercase tracking-widest mt-1" style={{ color: theme.primary }}>{provider.category}</p>
                          </div>
                          <div className="flex items-center gap-1 bg-orange-50 px-3 py-1.5 rounded-xl">
                            <Star className="w-4 h-4 text-brand-orange fill-brand-orange" />
                            <span className="text-sm font-black text-brand-orange">{provider.trustScore || 0}</span>
                          </div>
                        </div>
                        
                        <div className="flex items-center gap-2 text-gray-500 font-bold text-sm mb-6">
                          <MapPin className="w-4 h-4 text-brand-blue" />
                          {provider.city}
                        </div>

                        <p className="text-gray-600 text-sm font-medium line-clamp-2 mb-8 leading-relaxed">
                          {provider.description || "Aucune description fournie."}
                        </p>

                        <div className="flex items-center justify-between pt-6 border-t border-gray-50">
                          <span className="text-[10px] font-black text-gray-400 tracking-widest uppercase">DISPONIBLE</span>
                          <span className="font-black text-sm group-hover:translate-x-1 transition-transform flex items-center gap-1" style={{ color: theme.primary }}>
                            VOIR LE PROFIL <ChevronRight className="w-4 h-4" />
                          </span>
                        </div>
                      </div>
                    </Link>
                  </motion.div>
                );
              })}
            </div>
          ) : (
            <div className="bg-white rounded-[3rem] p-20 text-center border border-dashed border-gray-200">
              <div className="w-24 h-24 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-8">
                <SearchIcon className="w-12 h-12 text-gray-300" />
              </div>
              <h3 className="text-2xl font-extrabold text-gray-900 mb-4">Aucun résultat trouvé</h3>
              <p className="text-gray-500 font-medium mb-10 text-lg">Essayez de modifier vos filtres ou votre recherche.</p>
              <button 
                onClick={() => setFilters({ q: '', city: '', category: '', verified: false })}
                className="bg-brand-blue text-white px-10 py-4 rounded-2xl font-bold hover:bg-blue-700 transition-all shadow-xl shadow-blue-100"
              >
                Réinitialiser les filtres
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
