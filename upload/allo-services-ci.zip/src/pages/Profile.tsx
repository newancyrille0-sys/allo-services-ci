import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { doc, getDoc, collection, query, where, getDocs, addDoc, serverTimestamp, orderBy } from 'firebase/firestore';
import { db } from '../firebase';
import { useAuth } from '../contexts/AuthContext';
import { UserProfile, Post, Review } from '../types';
import { 
  MapPin, Star, ShieldCheck, Phone, MessageSquare, Calendar, 
  Clock, CheckCircle2, ChevronRight, Camera, Loader2, Send, 
  ArrowLeft, Share2, Heart, MessageCircle, Eye, Crown
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { cn, formatDate, getThemeColors } from '../lib/utils';

export default function Profile() {
  const { id } = useParams();
  const { user, profile: currentUserProfile } = useAuth();
  const navigate = useNavigate();
  
  const [provider, setProvider] = useState<UserProfile | null>(null);
  const [posts, setPosts] = useState<Post[]>([]);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [loading, setLoading] = useState(true);
  const [bookingLoading, setBookingLoading] = useState(false);
  const [showBookingModal, setShowBookingModal] = useState(false);
  const [bookingSuccess, setBookingSuccess] = useState(false);

  const [bookingData, setBookingData] = useState({
    date: '',
    time: '',
    message: '',
  });

  useEffect(() => {
    if (id) {
      fetchProviderData();
    }
  }, [id]);

  const fetchProviderData = async () => {
    setLoading(true);
    try {
      const docSnap = await getDoc(doc(db, 'users', id!));
      if (docSnap.exists()) {
        const data = docSnap.data() as UserProfile;
        if (data.role !== 'provider') {
          navigate('/');
          return;
        }
        setProvider(data);

        // Fetch posts
        const postsQuery = query(collection(db, 'posts'), where('providerId', '==', id), orderBy('createdAt', 'desc'));
        const postsSnap = await getDocs(postsQuery);
        setPosts(postsSnap.docs.map(d => ({ id: d.id, ...d.data() } as Post)));

        // Fetch reviews
        const reviewsQuery = query(collection(db, 'reviews'), where('providerId', '==', id), orderBy('createdAt', 'desc'));
        const reviewsSnap = await getDocs(reviewsQuery);
        setReviews(reviewsSnap.docs.map(d => ({ id: d.id, ...d.data() } as Review)));
      } else {
        navigate('/');
      }
    } catch (error) {
      console.error("Error fetching provider:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleBooking = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      navigate('/auth');
      return;
    }
    setBookingLoading(true);
    try {
      await addDoc(collection(db, 'bookings'), {
        clientId: user.uid,
        providerId: id,
        date: bookingData.date,
        time: bookingData.time,
        message: bookingData.message,
        status: 'pending',
        createdAt: serverTimestamp(),
      });
      setBookingSuccess(true);
      setTimeout(() => {
        setShowBookingModal(false);
        setBookingSuccess(false);
      }, 3000);
    } catch (error) {
      console.error("Error booking:", error);
    } finally {
      setBookingLoading(false);
    }
  };

  if (loading) return (
    <div className="min-h-screen flex flex-col items-center justify-center gap-4">
      <Loader2 className="w-10 h-10 text-brand-blue animate-spin" />
      <p className="text-gray-500 font-bold">Chargement du profil...</p>
    </div>
  );

  if (!provider) return null;

  const theme = getThemeColors(provider.subscriptionStatus);

  return (
    <div className="max-w-7xl mx-auto px-4 py-12">
      <button 
        onClick={() => navigate(-1)}
        className="flex items-center gap-2 text-gray-500 hover:text-brand-blue font-black text-xs uppercase tracking-widest mb-10 transition-colors"
      >
        <ArrowLeft className="w-5 h-5" />
        Retour
      </button>

      <div className="grid lg:grid-cols-3 gap-12">
        {/* Left Column: Profile Info */}
        <div className="lg:col-span-2 space-y-12">
          <div 
            className="bg-white rounded-[3.5rem] p-8 md:p-16 shadow-2xl shadow-gray-100 border border-gray-100"
            style={{ border: provider.subscriptionStatus !== 'free' ? theme.border : undefined }}
          >
            <div className="flex flex-col md:flex-row gap-12 items-start">
              <div className="relative shrink-0">
                <img 
                  src={provider.photoURL || `https://picsum.photos/seed/${provider.uid}/400/400`} 
                  alt={provider.displayName}
                  className="w-40 h-40 md:w-56 md:h-56 rounded-[3rem] object-cover shadow-2xl shadow-gray-200 border-4 border-white"
                  referrerPolicy="no-referrer"
                />
                {provider.isVerified && (
                  <div className="absolute -bottom-2 -right-2 bg-brand-blue text-white p-2.5 rounded-2xl shadow-xl border-4 border-white">
                    <ShieldCheck className="w-7 h-7" />
                  </div>
                )}
              </div>
              
              <div className="flex-grow">
                <div className="flex flex-wrap items-center gap-4 mb-3">
                  <h1 className="text-4xl md:text-5xl font-extrabold text-gray-900 tracking-tight">{provider.displayName}</h1>
                  {provider.subscriptionStatus === 'premium' && (
                    <span className="bg-brand-orange text-white px-4 py-1.5 rounded-full text-[10px] font-black shadow-lg flex items-center gap-1.5 tracking-widest uppercase">
                      <Crown className="w-3.5 h-3.5" /> PREMIUM+
                    </span>
                  )}
                  {provider.subscriptionStatus === 'monthly' && (
                    <span className="bg-emerald-500 text-white px-4 py-1.5 rounded-full text-[10px] font-black shadow-lg flex items-center gap-1.5 tracking-widest uppercase">
                      <CheckCircle2 className="w-3.5 h-3.5" /> VÉRIFIÉ
                    </span>
                  )}
                </div>
                
                <p className="text-xl font-black uppercase tracking-[0.2em] mb-6" style={{ color: theme.primary }}>{provider.category}</p>
                
                <div className="flex flex-wrap gap-6 mb-8">
                  <div className="flex items-center gap-2 text-gray-500 font-bold">
                    <MapPin className="w-5 h-5 text-brand-blue" />
                    {provider.city}
                  </div>
                  <div className="flex items-center gap-2 bg-orange-50 px-4 py-2 rounded-2xl">
                    <Star className="w-5 h-5 text-brand-orange fill-brand-orange" />
                    <span className="font-black text-brand-orange text-lg">{provider.trustScore || 0}</span>
                    <span className="text-xs font-bold text-brand-orange/60 uppercase tracking-wider ml-1">Score de confiance</span>
                  </div>
                </div>

                <p className="text-gray-600 text-xl leading-relaxed mb-10 font-medium">
                  {provider.description || "Ce prestataire n'a pas encore ajouté de description."}
                </p>

                <div className="flex flex-wrap gap-4">
                  <a 
                    href={`https://wa.me/${provider.phoneNumber?.replace(/\s/g, '')}`} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="flex-grow md:flex-none bg-green-500 text-white px-10 py-5 rounded-2xl font-black uppercase tracking-widest text-sm hover:bg-green-600 transition-all shadow-xl shadow-green-100 flex items-center justify-center gap-3 active:scale-95"
                  >
                    <MessageSquare className="w-5 h-5" />
                    WhatsApp
                  </a>
                  <button 
                    onClick={() => setShowBookingModal(true)}
                    className="flex-grow md:flex-none bg-brand-blue text-white px-10 py-5 rounded-2xl font-black uppercase tracking-widest text-sm hover:bg-blue-700 transition-all shadow-xl shadow-blue-100 flex items-center justify-center gap-3 active:scale-95"
                  >
                    <Calendar className="w-5 h-5" />
                    Réserver
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Social Posts Gallery */}
          <div className="space-y-8">
            <div className="flex items-center justify-between">
              <h2 className="text-3xl font-extrabold text-gray-900 tracking-tight flex items-center gap-3">
                <Camera className="w-8 h-8 text-brand-blue" />
                Réalisations
              </h2>
              <span className="text-gray-400 font-black text-xs uppercase tracking-widest">{posts.length} publications</span>
            </div>

            {posts.length > 0 ? (
              <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
                {posts.map((post) => (
                  <div 
                    key={post.id} 
                    className="group relative aspect-square rounded-[2.5rem] overflow-hidden bg-gray-100 cursor-pointer shadow-lg hover:shadow-2xl transition-all"
                  >
                    <img 
                      src={post.media[0].url} 
                      alt="" 
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-6 text-white backdrop-blur-[2px]">
                      <div className="flex items-center gap-2">
                        <Heart className="w-6 h-6 fill-white" />
                        <span className="font-black text-lg">{post.likes || 0}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Eye className="w-6 h-6" />
                        <span className="font-black text-lg">{post.views || 0}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="bg-white rounded-[3rem] p-20 text-center border border-dashed border-gray-200">
                <p className="text-gray-500 font-bold text-lg">Aucune réalisation publiée pour le moment.</p>
              </div>
            )}
          </div>

          {/* Reviews Section */}
          <div className="space-y-8">
            <h2 className="text-3xl font-extrabold text-gray-900 tracking-tight flex items-center gap-3">
              <Star className="w-8 h-8 text-brand-orange" />
              Avis Clients
            </h2>
            
            <div className="grid md:grid-cols-2 gap-6">
              {reviews.length > 0 ? reviews.map((review) => (
                <div key={review.id} className="bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-xl shadow-gray-50">
                  <div className="flex items-center justify-between mb-6">
                    <div className="flex items-center gap-1">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className={cn("w-5 h-5", i < review.rating ? "text-brand-orange fill-brand-orange" : "text-gray-200")} />
                      ))}
                    </div>
                    <span className="text-xs font-black text-gray-300 uppercase tracking-widest">{formatDate(review.createdAt.toDate())}</span>
                  </div>
                  <p className="text-gray-700 font-medium italic text-lg leading-relaxed">"{review.comment}"</p>
                </div>
              )) : (
                <p className="text-gray-500 font-bold italic text-lg">Aucun avis pour le moment.</p>
              )}
            </div>
          </div>
        </div>

        {/* Right Column: Trust & Info */}
        <div className="space-y-8">
          <div className="bg-gray-900 text-white rounded-[3.5rem] p-10 shadow-2xl shadow-gray-200 border border-white/10">
            <h3 className="text-2xl font-extrabold mb-10 flex items-center gap-3">
              <ShieldCheck className="w-8 h-8 text-brand-blue" />
              Garanties
            </h3>
            <ul className="space-y-10">
              <li className="flex gap-5">
                <div className="w-12 h-12 bg-white/10 rounded-2xl flex items-center justify-center shrink-0 border border-white/5">
                  <CheckCircle2 className="w-6 h-6 text-brand-blue" />
                </div>
                <div>
                  <p className="font-black text-lg mb-1">Identité vérifiée</p>
                  <p className="text-sm text-gray-400 font-medium leading-relaxed">Documents officiels et vidéo selfie validés par nos experts.</p>
                </div>
              </li>
              <li className="flex gap-5">
                <div className="w-12 h-12 bg-white/10 rounded-2xl flex items-center justify-center shrink-0 border border-white/5">
                  <CheckCircle2 className="w-6 h-6 text-brand-blue" />
                </div>
                <div>
                  <p className="font-black text-lg mb-1">Paiement après service</p>
                  <p className="text-sm text-gray-400 font-medium leading-relaxed">Ne payez jamais à l'avance. Le règlement se fait après satisfaction.</p>
                </div>
              </li>
              <li className="flex gap-5">
                <div className="w-12 h-12 bg-white/10 rounded-2xl flex items-center justify-center shrink-0 border border-white/5">
                  <CheckCircle2 className="w-6 h-6 text-brand-blue" />
                </div>
                <div>
                  <p className="font-black text-lg mb-1">Assistance 24/7</p>
                  <p className="text-sm text-gray-400 font-medium leading-relaxed">Notre équipe est là pour vous accompagner en cas de litige.</p>
                </div>
              </li>
            </ul>
          </div>

          <div className="bg-white rounded-[3rem] p-10 border border-gray-100 shadow-2xl shadow-gray-100">
            <h3 className="text-xl font-extrabold text-gray-900 mb-8 tracking-tight">Partager ce profil</h3>
            <div className="flex gap-4">
              <button className="flex-grow bg-gray-50 p-5 rounded-2xl hover:bg-gray-100 transition-all flex items-center justify-center gap-3 text-gray-700 font-black uppercase tracking-widest text-xs active:scale-95">
                <Share2 className="w-5 h-5 text-brand-blue" />
                Copier le lien
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Booking Modal */}
      <AnimatePresence>
        {showBookingModal && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowBookingModal(false)}
              className="absolute inset-0 bg-black/70 backdrop-blur-md"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 40 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 40 }}
              className="relative w-full max-w-xl bg-white rounded-[4rem] p-10 md:p-16 shadow-2xl overflow-hidden"
            >
              {bookingSuccess ? (
                <div className="text-center py-16">
                  <div className="w-24 h-24 bg-green-100 text-green-600 rounded-[2rem] flex items-center justify-center mx-auto mb-8 shadow-xl shadow-green-50">
                    <CheckCircle2 className="w-12 h-12" />
                  </div>
                  <h3 className="text-3xl font-extrabold text-gray-900 mb-4 tracking-tight">Demande envoyée !</h3>
                  <p className="text-gray-500 font-bold text-lg">Le prestataire vous contactera sous peu pour confirmer.</p>
                </div>
              ) : (
                <>
                  <h3 className="text-3xl font-extrabold text-gray-900 mb-3 tracking-tight">Réserver {provider.displayName}</h3>
                  <p className="text-gray-500 font-bold mb-12">Remplissez les détails pour votre demande de service.</p>
                  
                  <form onSubmit={handleBooking} className="space-y-8">
                    <div className="grid grid-cols-2 gap-6">
                      <div className="space-y-3">
                        <label className="text-xs font-black text-gray-400 uppercase tracking-widest ml-1">Date</label>
                        <div className="relative">
                          <Calendar className="absolute left-5 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                          <input 
                            type="date" 
                            required
                            className="w-full pl-14 pr-6 py-5 bg-gray-50 border border-gray-100 rounded-[2rem] outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-brand-blue transition-all font-bold"
                            value={bookingData.date}
                            onChange={(e) => setBookingData(prev => ({ ...prev, date: e.target.value }))}
                          />
                        </div>
                      </div>
                      <div className="space-y-3">
                        <label className="text-xs font-black text-gray-400 uppercase tracking-widest ml-1">Heure</label>
                        <div className="relative">
                          <Clock className="absolute left-5 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                          <input 
                            type="time" 
                            required
                            className="w-full pl-14 pr-6 py-5 bg-gray-50 border border-gray-100 rounded-[2rem] outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-brand-blue transition-all font-bold"
                            value={bookingData.time}
                            onChange={(e) => setBookingData(prev => ({ ...prev, time: e.target.value }))}
                          />
                        </div>
                      </div>
                    </div>

                    <div className="space-y-3">
                      <label className="text-xs font-black text-gray-400 uppercase tracking-widest ml-1">Message (Optionnel)</label>
                      <textarea 
                        placeholder="Décrivez votre besoin..."
                        className="w-full p-6 bg-gray-50 border border-gray-100 rounded-[2rem] outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-brand-blue transition-all h-40 resize-none font-bold"
                        value={bookingData.message}
                        onChange={(e) => setBookingData(prev => ({ ...prev, message: e.target.value }))}
                      />
                    </div>

                    <div className="bg-blue-50 p-6 rounded-[2rem] flex gap-4 text-sm text-brand-blue border border-blue-100/50">
                      <ShieldCheck className="w-6 h-6 shrink-0" />
                      <p className="font-bold leading-relaxed">Le paiement se fait après la prestation. Allo Services ne vous demandera jamais d'argent à l'avance.</p>
                    </div>

                    <button 
                      type="submit"
                      disabled={bookingLoading}
                      className="w-full bg-brand-blue text-white py-6 rounded-[2rem] font-black uppercase tracking-[0.2em] text-sm hover:bg-blue-700 transition-all shadow-2xl shadow-blue-100 flex items-center justify-center gap-3 active:scale-95 disabled:opacity-50"
                    >
                      {bookingLoading ? <Loader2 className="w-7 h-7 animate-spin" /> : 'Confirmer la réservation'}
                    </button>
                  </form>
                </>
              )}
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
