import React, { useState, useEffect } from 'react';
import { collection, query, where, onSnapshot, doc, updateDoc, addDoc, serverTimestamp, orderBy } from 'firebase/firestore';
import { db, auth } from '../firebase';
import { useAuth } from '../contexts/AuthContext';
import { UserProfile, Booking, Post } from '../types';
import { 
  LayoutDashboard, User, Calendar, Camera, CreditCard, 
  CheckCircle2, Clock, XCircle, Plus, Image as ImageIcon, 
  Loader2, ShieldCheck, Star, MessageSquare
} from 'lucide-react';
import { motion } from 'framer-motion';
import { cn, formatDate, CATEGORIES, CITIES } from '../lib/utils';

export default function Dashboard() {
  const { user, profile } = useAuth();
  const [activeTab, setActiveTab] = useState<'overview' | 'bookings' | 'posts' | 'profile' | 'premium'>('overview');
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);

  // Form states
  const [postForm, setPostForm] = useState({ caption: '', imageUrl: '' });
  const [profileForm, setProfileForm] = useState({ 
    displayName: '', description: '', phoneNumber: '', city: '', category: '' 
  });
  const [paymentForm, setPaymentForm] = useState({ proofUrl: '' });

  useEffect(() => {
    if (profile) {
      setProfileForm({
        displayName: profile.displayName || '',
        description: profile.description || '',
        phoneNumber: profile.phoneNumber || '',
        city: profile.city || '',
        category: profile.category || '',
      });
    }
  }, [profile]);

  useEffect(() => {
    if (user && profile) {
      const bookingField = profile.role === 'provider' ? 'providerId' : 'clientId';
      const q = query(collection(db, 'bookings'), where(bookingField, '==', user.uid), orderBy('createdAt', 'desc'));
      
      const unsubscribe = onSnapshot(q, (snapshot) => {
        setBookings(snapshot.docs.map(d => ({ id: d.id, ...d.data() } as Booking)));
        setLoading(false);
      });

      return () => unsubscribe();
    }
  }, [user, profile]);

  useEffect(() => {
    if (user && profile?.role === 'provider') {
      const q = query(collection(db, 'posts'), where('providerId', '==', user.uid), orderBy('createdAt', 'desc'));
      const unsubscribe = onSnapshot(q, (snapshot) => {
        setPosts(snapshot.docs.map(d => ({ id: d.id, ...d.data() } as Post)));
      });
      return () => unsubscribe();
    }
  }, [user, profile]);

  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    try {
      await updateDoc(doc(db, 'users', user.uid), profileForm);
      alert('Profil mis à jour !');
    } catch (error) {
      console.error(error);
    }
  };

  const handleCreatePost = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    try {
      await addDoc(collection(db, 'posts'), {
        providerId: user.uid,
        caption: postForm.caption,
        media: [{ url: postForm.imageUrl, type: 'image' }],
        createdAt: serverTimestamp(),
        likes: 0,
        views: 0
      });
      setPostForm({ caption: '', imageUrl: '' });
      alert('Post publié !');
    } catch (error) {
      console.error(error);
    }
  };

  const handleUpdateBookingStatus = async (bookingId: string, status: string) => {
    try {
      await updateDoc(doc(db, 'bookings', bookingId), { status });
    } catch (error) {
      console.error(error);
    }
  };

  const handlePaymentSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    try {
      await updateDoc(doc(db, 'users', user.uid), { 
        paymentProof: paymentForm.proofUrl,
        isPremiumPending: true 
      });
      alert('Preuve de paiement envoyée ! Un administrateur va valider votre compte.');
    } catch (error) {
      console.error(error);
    }
  };

  if (loading) return <div className="min-h-screen flex items-center justify-center"><Loader2 className="animate-spin text-brand-blue" /></div>;

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row gap-8">
        {/* Sidebar */}
        <aside className="w-full md:w-64 shrink-0">
          <div className="bg-white rounded-[2rem] p-6 shadow-xl shadow-gray-100 border border-gray-100 sticky top-24">
            <div className="flex items-center gap-3 mb-8 px-2">
              <div className="w-12 h-12 bg-brand-blue rounded-2xl flex items-center justify-center text-white font-bold text-xl">
                {profile?.displayName?.[0] || 'U'}
              </div>
              <div>
                <p className="font-bold text-gray-900 truncate max-w-[120px]">{profile?.displayName}</p>
                <p className="text-xs text-gray-500 uppercase font-bold">{profile?.role}</p>
              </div>
            </div>

            <nav className="space-y-2">
              <button 
                onClick={() => setActiveTab('overview')}
                className={cn(
                  "w-full flex items-center gap-3 px-4 py-3 rounded-xl font-bold transition-all",
                  activeTab === 'overview' ? "bg-brand-blue text-white shadow-lg shadow-blue-200" : "text-gray-500 hover:bg-gray-50"
                )}
              >
                <LayoutDashboard className="w-5 h-5" />
                Vue d'ensemble
              </button>
              <button 
                onClick={() => setActiveTab('bookings')}
                className={cn(
                  "w-full flex items-center gap-3 px-4 py-3 rounded-xl font-bold transition-all",
                  activeTab === 'bookings' ? "bg-brand-blue text-white shadow-lg shadow-blue-200" : "text-gray-500 hover:bg-gray-50"
                )}
              >
                <Calendar className="w-5 h-5" />
                Réservations
              </button>
              {profile?.role === 'provider' && (
                <>
                  <button 
                    onClick={() => setActiveTab('posts')}
                    className={cn(
                      "w-full flex items-center gap-3 px-4 py-3 rounded-xl font-bold transition-all",
                      activeTab === 'posts' ? "bg-brand-blue text-white shadow-lg shadow-blue-200" : "text-gray-500 hover:bg-gray-50"
                    )}
                  >
                    <Camera className="w-5 h-5" />
                    Mes Posts
                  </button>
                  <button 
                    onClick={() => setActiveTab('premium')}
                    className={cn(
                      "w-full flex items-center gap-3 px-4 py-3 rounded-xl font-bold transition-all",
                      activeTab === 'premium' ? "bg-brand-blue text-white shadow-lg shadow-blue-200" : "text-gray-500 hover:bg-gray-50"
                    )}
                  >
                    <CreditCard className="w-5 h-5" />
                    Premium
                  </button>
                </>
              )}
              <button 
                onClick={() => setActiveTab('profile')}
                className={cn(
                  "w-full flex items-center gap-3 px-4 py-3 rounded-xl font-bold transition-all",
                  activeTab === 'profile' ? "bg-brand-blue text-white shadow-lg shadow-blue-200" : "text-gray-500 hover:bg-gray-50"
                )}
              >
                <User className="w-5 h-5" />
                Mon Profil
              </button>
            </nav>
          </div>
        </aside>

        {/* Main Content */}
        <div className="flex-grow space-y-8">
          {activeTab === 'overview' && (
            <div className="grid md:grid-cols-3 gap-6">
              <div className="bg-white p-8 rounded-[2.5rem] shadow-xl shadow-gray-100 border border-gray-100">
                <p className="text-gray-500 font-bold text-sm uppercase mb-2">Réservations</p>
                <p className="text-4xl font-black text-gray-900">{bookings.length}</p>
              </div>
              {profile?.role === 'provider' && (
                <>
                  <div className="bg-white p-8 rounded-[2.5rem] shadow-xl shadow-gray-100 border border-gray-100">
                    <p className="text-gray-500 font-bold text-sm uppercase mb-2">Publications</p>
                    <p className="text-4xl font-black text-gray-900">{posts.length}</p>
                  </div>
                  <div className="bg-white p-8 rounded-[2.5rem] shadow-xl shadow-gray-100 border border-gray-100">
                    <p className="text-gray-500 font-bold text-sm uppercase mb-2">Score</p>
                    <p className="text-4xl font-black text-brand-orange">{profile.trustScore || 0}</p>
                  </div>
                </>
              )}
            </div>
          )}

          {activeTab === 'bookings' && (
            <div className="space-y-6">
              <h2 className="text-2xl font-bold text-gray-900">Mes Réservations</h2>
              <div className="grid gap-4">
                {bookings.length > 0 ? bookings.map(booking => (
                  <div key={booking.id} className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div className="flex items-center gap-4">
                      <div className={cn(
                        "w-12 h-12 rounded-2xl flex items-center justify-center",
                        booking.status === 'pending' ? "bg-blue-50 text-brand-blue" :
                        booking.status === 'confirmed' ? "bg-green-50 text-green-600" :
                        "bg-gray-50 text-gray-400"
                      )}>
                        {booking.status === 'pending' ? <Clock className="w-6 h-6" /> :
                         booking.status === 'confirmed' ? <CheckCircle2 className="w-6 h-6" /> :
                         <XCircle className="w-6 h-6" />}
                      </div>
                      <div>
                        <p className="font-bold text-gray-900">Le {formatDate(new Date(booking.date))} à {booking.time}</p>
                        <p className="text-sm text-gray-500">{booking.message}</p>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      {profile?.role === 'provider' && booking.status === 'pending' && (
                        <>
                          <button 
                            onClick={() => handleUpdateBookingStatus(booking.id, 'confirmed')}
                            className="bg-green-500 text-white px-4 py-2 rounded-xl font-bold text-sm hover:bg-green-600 transition-all"
                          >
                            Confirmer
                          </button>
                          <button 
                            onClick={() => handleUpdateBookingStatus(booking.id, 'cancelled')}
                            className="bg-red-50 text-red-500 px-4 py-2 rounded-xl font-bold text-sm hover:bg-red-100 transition-all"
                          >
                            Refuser
                          </button>
                        </>
                      )}
                      <span className={cn(
                        "px-4 py-2 rounded-xl font-bold text-xs uppercase tracking-wider",
                        booking.status === 'pending' ? "bg-blue-100 text-brand-blue" :
                        booking.status === 'confirmed' ? "bg-green-100 text-green-600" :
                        "bg-gray-100 text-gray-500"
                      )}>
                        {booking.status}
                      </span>
                    </div>
                  </div>
                )) : (
                  <p className="text-gray-500 italic text-center py-12">Aucune réservation trouvée.</p>
                )}
              </div>
            </div>
          )}

          {activeTab === 'posts' && (
            <div className="space-y-8">
              <div className="bg-white p-8 rounded-[2.5rem] shadow-xl shadow-gray-100 border border-gray-100">
                <h3 className="text-xl font-bold text-gray-900 mb-6 flex items-center gap-2">
                  <Plus className="w-6 h-6 text-brand-blue" />
                  Nouvelle Publication
                </h3>
                <form onSubmit={handleCreatePost} className="space-y-4">
                  <textarea 
                    placeholder="Décrivez votre réalisation..."
                    className="w-full p-4 bg-gray-50 border border-gray-100 rounded-2xl outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-brand-blue transition-all h-32 resize-none"
                    value={postForm.caption}
                    onChange={(e) => setPostForm(prev => ({ ...prev, caption: e.target.value }))}
                    required
                  />
                  <div className="relative">
                    <ImageIcon className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <input 
                      type="url" 
                      placeholder="URL de l'image"
                      className="w-full pl-12 pr-4 py-4 bg-gray-50 border border-gray-100 rounded-2xl outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-brand-blue transition-all"
                      value={postForm.imageUrl}
                      onChange={(e) => setPostForm(prev => ({ ...prev, imageUrl: e.target.value }))}
                      required
                    />
                  </div>
                  <button 
                    type="submit"
                    className="w-full bg-brand-blue text-white py-4 rounded-2xl font-bold hover:bg-blue-700 transition-all shadow-xl shadow-blue-100"
                  >
                    Publier
                  </button>
                </form>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {posts.map(post => (
                  <div key={post.id} className="aspect-square rounded-3xl overflow-hidden bg-gray-100 relative group">
                    <img src={post.media[0].url} alt="" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                    <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-white font-bold">
                      {post.likes || 0} Likes
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'profile' && (
            <div className="bg-white p-8 md:p-12 rounded-[3rem] shadow-xl shadow-gray-100 border border-gray-100">
              <h2 className="text-2xl font-bold text-gray-900 mb-8">Paramètres du Profil</h2>
              <form onSubmit={handleUpdateProfile} className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-gray-700">Nom Complet</label>
                    <input 
                      type="text" 
                      className="w-full p-4 bg-gray-50 border border-gray-100 rounded-2xl outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-brand-blue transition-all"
                      value={profileForm.displayName}
                      onChange={(e) => setProfileForm(prev => ({ ...prev, displayName: e.target.value }))}
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-gray-700">Téléphone</label>
                    <input 
                      type="tel" 
                      className="w-full p-4 bg-gray-50 border border-gray-100 rounded-2xl outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-brand-blue transition-all"
                      value={profileForm.phoneNumber}
                      onChange={(e) => setProfileForm(prev => ({ ...prev, phoneNumber: e.target.value }))}
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-gray-700">Ville</label>
                    <select 
                      className="w-full p-4 bg-gray-50 border border-gray-100 rounded-2xl outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-brand-blue transition-all appearance-none"
                      value={profileForm.city}
                      onChange={(e) => setProfileForm(prev => ({ ...prev, city: e.target.value }))}
                    >
                      {CITIES.map(c => <option key={c} value={c}>{c}</option>)}
                    </select>
                  </div>
                  {profile?.role === 'provider' && (
                    <div className="space-y-2">
                      <label className="text-sm font-bold text-gray-700">Catégorie</label>
                      <select 
                        className="w-full p-4 bg-gray-50 border border-gray-100 rounded-2xl outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-brand-blue transition-all appearance-none"
                        value={profileForm.category}
                        onChange={(e) => setProfileForm(prev => ({ ...prev, category: e.target.value }))}
                      >
                        {CATEGORIES.map(c => <option key={c.name} value={c.name}>{c.name}</option>)}
                      </select>
                    </div>
                  )}
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-gray-700">Description / Bio</label>
                  <textarea 
                    className="w-full p-4 bg-gray-50 border border-gray-100 rounded-2xl outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-brand-blue transition-all h-40 resize-none"
                    value={profileForm.description}
                    onChange={(e) => setProfileForm(prev => ({ ...prev, description: e.target.value }))}
                  />
                </div>
                <button 
                  type="submit"
                  className="w-full bg-brand-blue text-white py-4 rounded-2xl font-bold hover:bg-blue-700 transition-all shadow-xl shadow-blue-100"
                >
                  Enregistrer les modifications
                </button>
              </form>
            </div>
          )}

          {activeTab === 'premium' && (
            <div className="bg-white p-8 md:p-12 rounded-[3rem] shadow-xl shadow-gray-100 border border-gray-100">
              <div className="flex items-center gap-4 mb-8">
                <div className="w-16 h-16 bg-brand-orange/10 text-brand-orange rounded-[1.5rem] flex items-center justify-center">
                  <Star className="w-8 h-8 fill-brand-orange" />
                </div>
                <div>
                  <h2 className="text-2xl font-bold text-gray-900">Devenir Premium</h2>
                  <p className="text-gray-500">Boostez votre visibilité et gagnez plus de clients.</p>
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-12 items-center">
                <div className="space-y-6">
                  <div className="bg-brand-orange/5 p-6 rounded-3xl border border-brand-orange/10">
                    <p className="text-sm font-bold text-brand-orange uppercase mb-1">Abonnement Mensuel</p>
                    <p className="text-3xl font-black text-gray-900">5 000 FCFA <span className="text-sm font-normal text-gray-500">/ mois</span></p>
                  </div>
                  <ul className="space-y-4">
                    {[
                      "Badge 'Premium' sur votre profil",
                      "Apparaître en haut des résultats de recherche",
                      "Publications illimitées sur le fil social",
                      "Statistiques détaillées de vos vues"
                    ].map(item => (
                      <li key={item} className="flex items-center gap-3 text-gray-700 font-medium">
                        <CheckCircle2 className="w-5 h-5 text-brand-orange" />
                        {item}
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="bg-gray-50 p-8 rounded-[2rem] border border-gray-100">
                  <h4 className="font-bold text-gray-900 mb-4">Comment payer ?</h4>
                  <p className="text-sm text-gray-600 mb-6">
                    Envoyez 5 000 FCFA via <strong>Wave</strong> ou <strong>Orange Money</strong> au numéro : <br />
                    <span className="text-lg font-black text-brand-orange">+225 07 00 00 00 00</span>
                  </p>
                  <form onSubmit={handlePaymentSubmit} className="space-y-4">
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-gray-500 uppercase">Preuve de paiement (Capture d'écran)</label>
                      <input 
                        type="url" 
                        placeholder="URL de l'image de preuve"
                        className="w-full p-4 bg-white border border-gray-100 rounded-xl outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-brand-blue transition-all"
                        value={paymentForm.proofUrl}
                        onChange={(e) => setPaymentForm(prev => ({ ...prev, proofUrl: e.target.value }))}
                        required
                      />
                    </div>
                    <button 
                      type="submit"
                      className="w-full bg-gray-900 text-white py-4 rounded-xl font-bold hover:bg-gray-800 transition-all"
                    >
                      Envoyer pour validation
                    </button>
                  </form>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
