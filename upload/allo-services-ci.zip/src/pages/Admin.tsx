import React, { useState, useEffect } from 'react';
import { collection, query, where, onSnapshot, doc, updateDoc, getDocs, setDoc, Timestamp, deleteDoc } from 'firebase/firestore';
import { db } from '../firebase';
import { UserProfile, Post } from '../types';
import { 
  ShieldCheck, UserCheck, CreditCard, AlertTriangle, 
  CheckCircle2, XCircle, Loader2, Lock, Eye, Trash2, Database, Zap
} from 'lucide-react';
import { cn, formatDate } from '../lib/utils';

export default function Admin() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [accessCode, setAccessCode] = useState('');
  const [pendingProviders, setPendingProviders] = useState<UserProfile[]>([]);
  const [pendingPayments, setPendingPayments] = useState<UserProfile[]>([]);
  const [allPosts, setAllPosts] = useState<(Post & { providerName?: string })[]>([]);
  const [loading, setLoading] = useState(true);
  const [isSeeding, setIsSeeding] = useState(false);

  const SECRET_CODE = 'Cy-73-admi-03';

  useEffect(() => {
    if (isAuthenticated) {
      // Fetch pending verifications
      const qProviders = query(collection(db, 'users'), where('role', '==', 'provider'), where('isVerified', '==', false));
      const unsubProviders = onSnapshot(qProviders, (snap) => {
        setPendingProviders(snap.docs.map(d => d.data() as UserProfile));
      });

      // Fetch pending payments
      const qPayments = query(collection(db, 'users'), where('isPremiumPending', '==', true));
      const unsubPayments = onSnapshot(qPayments, (snap) => {
        setPendingPayments(snap.docs.map(d => d.data() as UserProfile));
      });

      // Fetch all posts for moderation
      const qPosts = query(collection(db, 'posts'));
      const unsubPosts = onSnapshot(qPosts, (snap) => {
        setAllPosts(snap.docs.map(d => ({ id: d.id, ...d.data() } as Post)));
      });

      setLoading(false);
      return () => {
        unsubProviders();
        unsubPayments();
        unsubPosts();
      };
    }
  }, [isAuthenticated]);

  const handleAuth = (e: React.FormEvent) => {
    e.preventDefault();
    if (accessCode === SECRET_CODE) {
      setIsAuthenticated(true);
    } else {
      alert('Code incorrect');
    }
  };

  const handleVerifyProvider = async (uid: string) => {
    try {
      await updateDoc(doc(db, 'users', uid), { isVerified: true });
    } catch (error) {
      console.error(error);
    }
  };

  const handleApprovePremium = async (uid: string) => {
    try {
      await updateDoc(doc(db, 'users', uid), { 
        isPremium: true, 
        subscriptionStatus: 'premium',
        isPremiumPending: false 
      });
    } catch (error) {
      console.error(error);
    }
  };

  const handleDeletePost = async (postId: string) => {
    if (window.confirm('Supprimer ce post ?')) {
      try {
        await deleteDoc(doc(db, 'posts', postId));
      } catch (error) {
        console.error(error);
      }
    }
  };

  const seedDemoData = async () => {
    if (!window.confirm('Voulez-vous générer les données de démonstration ? Cela ajoutera 5 prestataires types.')) return;
    
    setIsSeeding(true);
    try {
      const demoProviders = [
        {
          uid: 'demo_1',
          displayName: 'Kouassi Jean',
          email: 'jean@demo.ci',
          role: 'provider',
          category: 'Plomberie',
          city: 'Abidjan (Cocody)',
          description: 'Expert en plomberie avec 10 ans d\'expérience. Disponible 24/7 pour urgences.',
          trustScore: 95,
          isVerified: true,
          subscriptionStatus: 'premium',
          createdAt: Timestamp.now(),
          photoURL: 'https://picsum.photos/seed/jean/400/400'
        },
        {
          uid: 'demo_2',
          displayName: 'Aminata Diallo',
          email: 'aminata@demo.ci',
          role: 'provider',
          category: 'Électricité',
          city: 'Abidjan (Yopougon)',
          description: 'Électricienne certifiée. Installation et dépannage rapide.',
          trustScore: 98,
          isVerified: true,
          subscriptionStatus: 'premium',
          createdAt: Timestamp.now(),
          photoURL: 'https://picsum.photos/seed/aminata/400/400'
        },
        {
          uid: 'demo_3',
          displayName: 'Ibrahim Koné',
          email: 'ibrahim@demo.ci',
          role: 'provider',
          category: 'Ménage & Nettoyage',
          city: 'Abidjan (Marcory)',
          description: 'Services de nettoyage professionnel pour bureaux et domiciles.',
          trustScore: 85,
          isVerified: true,
          subscriptionStatus: 'monthly',
          createdAt: Timestamp.now(),
          photoURL: 'https://picsum.photos/seed/ibrahim/400/400'
        },
        {
          uid: 'demo_4',
          displayName: 'Fatou Traoré',
          email: 'fatou@demo.ci',
          role: 'provider',
          category: 'Climatisation',
          city: 'Abidjan (Plateau)',
          description: 'Installation et entretien de climatiseurs toutes marques.',
          trustScore: 75,
          isVerified: false,
          subscriptionStatus: 'free',
          createdAt: Timestamp.now(),
          photoURL: 'https://picsum.photos/seed/fatou/400/400'
        },
        {
          uid: 'demo_5',
          displayName: 'Moussa Diabaté',
          email: 'moussa@demo.ci',
          role: 'provider',
          category: 'Peinture',
          city: 'Abidjan (Treichville)',
          description: 'Peintre décorateur. Redonnez vie à vos murs avec des couleurs éclatantes.',
          trustScore: 90,
          isVerified: true,
          subscriptionStatus: 'monthly',
          createdAt: Timestamp.now(),
          photoURL: 'https://picsum.photos/seed/moussa/400/400'
        }
      ];

      for (const provider of demoProviders) {
        await setDoc(doc(db, 'users', provider.uid), provider);
      }

      alert('Données de démonstration générées avec succès !');
    } catch (error) {
      console.error(error);
      alert('Erreur lors de la génération des données');
    } finally {
      setIsSeeding(false);
    }
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center p-4 bg-gray-900">
        <div className="max-w-md w-full bg-white/10 backdrop-blur-xl border border-white/10 p-12 rounded-[3rem] text-center">
          <div className="w-20 h-20 bg-brand-blue rounded-3xl flex items-center justify-center mx-auto mb-8 shadow-2xl shadow-blue-600/20">
            <Lock className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-white mb-2">Accès Restreint</h1>
          <p className="text-gray-400 mb-8">Veuillez entrer le code administrateur pour continuer.</p>
          <form onSubmit={handleAuth} className="space-y-4">
            <input 
              type="password" 
              placeholder="Code d'accès"
              className="w-full bg-white/5 border border-white/10 p-4 rounded-2xl text-white text-center text-2xl tracking-[1em] outline-none focus:border-brand-blue transition-all"
              value={accessCode}
              onChange={(e) => setAccessCode(e.target.value)}
              autoFocus
            />
            <button className="w-full bg-brand-blue text-white py-4 rounded-2xl font-bold hover:bg-blue-700 transition-all">
              Déverrouiller
            </button>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-12">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
        <div>
          <h1 className="text-4xl font-black text-gray-900">Dashboard Admin</h1>
          <p className="text-gray-500">Gestion de la plateforme Allo Services CI</p>
        </div>
        <div className="flex flex-wrap gap-4">
          <button 
            onClick={seedDemoData}
            disabled={isSeeding}
            className="bg-blue-600 text-white px-6 py-3 rounded-2xl font-bold flex items-center gap-2 hover:bg-blue-700 transition-all disabled:opacity-50"
          >
            {isSeeding ? <Loader2 className="w-5 h-5 animate-spin" /> : <Database className="w-5 h-5" />}
            Générer Démo
          </button>
          <div className="bg-brand-blue text-white px-6 py-3 rounded-2xl font-bold flex items-center gap-2">
            <ShieldCheck className="w-5 h-5" />
            Mode Administrateur
          </div>
        </div>
      </div>

      <div className="grid lg:grid-cols-2 gap-8">
        {/* Provider Verifications */}
        <div className="bg-white rounded-[3rem] p-8 shadow-xl shadow-gray-100 border border-gray-100">
          <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center gap-2">
            <UserCheck className="w-6 h-6 text-blue-500" />
            Vérifications en attente
          </h2>
          <div className="space-y-4">
            {pendingProviders.length > 0 ? pendingProviders.map(p => (
              <div key={p.uid} className="p-6 bg-gray-50 rounded-3xl flex items-center justify-between gap-4">
                <div>
                  <p className="font-bold text-gray-900">{p.displayName}</p>
                  <p className="text-sm text-gray-500">{p.category} • {p.city}</p>
                </div>
                <div className="flex gap-2">
                  <button 
                    onClick={() => handleVerifyProvider(p.uid)}
                    className="bg-blue-500 text-white px-4 py-2 rounded-xl font-bold text-sm hover:bg-blue-600 transition-all"
                  >
                    Vérifier
                  </button>
                </div>
              </div>
            )) : (
              <p className="text-gray-500 italic text-center py-8">Aucune vérification en attente.</p>
            )}
          </div>
        </div>

        {/* Payment Validations */}
        <div className="bg-white rounded-[3rem] p-8 shadow-xl shadow-gray-100 border border-gray-100">
          <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center gap-2">
            <CreditCard className="w-6 h-6 text-green-500" />
            Paiements Premium
          </h2>
          <div className="space-y-4">
            {pendingPayments.length > 0 ? pendingPayments.map(p => (
              <div key={p.uid} className="p-6 bg-gray-50 rounded-3xl flex items-center justify-between gap-4">
                <div>
                  <p className="font-bold text-gray-900">{p.displayName}</p>
                  <a href={p.paymentProof} target="_blank" rel="noreferrer" className="text-xs text-brand-orange font-bold hover:underline">Voir la preuve</a>
                </div>
                <button 
                  onClick={() => handleApprovePremium(p.uid)}
                  className="bg-green-500 text-white px-4 py-2 rounded-xl font-bold text-sm hover:bg-green-600 transition-all"
                >
                  Approuver
                </button>
              </div>
            )) : (
              <p className="text-gray-500 italic text-center py-8">Aucun paiement en attente.</p>
            )}
          </div>
        </div>

        {/* Content Moderation */}
        <div className="lg:col-span-2 bg-white rounded-[3rem] p-8 shadow-xl shadow-gray-100 border border-gray-100">
          <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center gap-2">
            <AlertTriangle className="w-6 h-6 text-brand-orange" />
            Modération des contenus
          </h2>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {allPosts.map(post => (
              <div key={post.id} className="group relative aspect-square rounded-3xl overflow-hidden bg-gray-100">
                <img src={post.media[0].url} alt="" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center p-4 text-center">
                  <p className="text-white text-xs font-bold mb-4 line-clamp-2">{post.caption}</p>
                  <button 
                    onClick={() => handleDeletePost(post.id)}
                    className="bg-red-500 text-white p-3 rounded-2xl hover:bg-red-600 transition-all"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
