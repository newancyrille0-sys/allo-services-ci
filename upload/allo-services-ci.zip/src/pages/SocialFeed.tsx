import React, { useState, useEffect } from 'react';
import { collection, query, orderBy, onSnapshot, limit, doc, getDoc } from 'firebase/firestore';
import { db } from '../firebase';
import { Post, UserProfile } from '../types';
import { 
  Heart, MessageCircle, Share2, MoreHorizontal, ShieldCheck, 
  MapPin, Camera, Loader2, Eye
} from 'lucide-react';
import { motion } from 'framer-motion';
import { cn, formatDate } from '../lib/utils';
import { Link } from 'react-router-dom';

export default function SocialFeed() {
  const [posts, setPosts] = useState<(Post & { provider?: UserProfile })[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const q = query(collection(db, 'posts'), orderBy('createdAt', 'desc'), limit(50));
    
    const unsubscribe = onSnapshot(q, async (snapshot) => {
      const postsData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Post));
      
      // Fetch provider info for each post
      const postsWithProviders = await Promise.all(postsData.map(async (post) => {
        const pSnap = await getDoc(doc(db, 'users', post.providerId));
        return { ...post, provider: pSnap.exists() ? pSnap.data() as UserProfile : undefined };
      }));

      setPosts(postsWithProviders);
      setLoading(false);
    }, (error) => {
      console.error("Error fetching feed:", error);
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  if (loading) return (
    <div className="min-h-screen flex flex-col items-center justify-center gap-4">
      <Loader2 className="w-10 h-10 text-brand-blue animate-spin" />
      <p className="text-gray-500 font-bold">Chargement du fil d'actualité...</p>
    </div>
  );

  return (
    <div className="max-w-2xl mx-auto px-4 py-12">
      <div className="flex items-center justify-between mb-10">
        <h1 className="text-4xl font-extrabold text-gray-900 tracking-tight">Réalisations</h1>
        <div className="flex items-center gap-2 text-brand-blue bg-blue-50 px-5 py-2.5 rounded-full font-black text-xs uppercase tracking-widest">
          <Camera className="w-4 h-4" />
          En direct
        </div>
      </div>

      <div className="space-y-12">
        {posts.length > 0 ? posts.map((post, i) => (
          <motion.div
            key={post.id}
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className="bg-white rounded-[3rem] border border-gray-100 shadow-2xl shadow-gray-100 overflow-hidden"
          >
            {/* Post Header */}
            <div className="p-8 flex items-center justify-between">
              <Link to={`/provider/${post.providerId}`} className="flex items-center gap-4 group">
                <div className="relative">
                  <img 
                    src={post.provider?.photoURL || `https://picsum.photos/seed/${post.providerId}/100/100`} 
                    alt="" 
                    className="w-14 h-14 rounded-2xl object-cover border-2 border-white shadow-lg group-hover:scale-110 transition-transform duration-500"
                    referrerPolicy="no-referrer"
                  />
                  {post.provider?.isVerified && (
                    <div className="absolute -bottom-1 -right-1 bg-brand-blue text-white p-1 rounded-full border-2 border-white shadow-sm">
                      <ShieldCheck className="w-3 h-3" />
                    </div>
                  )}
                </div>
                <div>
                  <h3 className="font-extrabold text-gray-900 text-lg group-hover:text-brand-blue transition-colors leading-none mb-1.5">{post.provider?.displayName}</h3>
                  <div className="flex items-center gap-2 text-[10px] text-gray-400 font-black uppercase tracking-widest">
                    <span className="text-brand-blue">{post.provider?.category}</span>
                    <span className="text-gray-200">•</span>
                    <span>{formatDate(post.createdAt.toDate())}</span>
                  </div>
                </div>
              </Link>
              <button className="p-2 text-gray-400 hover:text-gray-900 transition-colors">
                <MoreHorizontal className="w-6 h-6" />
              </button>
            </div>

            {/* Post Media */}
            <div className="relative aspect-square md:aspect-video bg-gray-100 overflow-hidden">
              <img 
                src={post.media[0].url} 
                alt="" 
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                referrerPolicy="no-referrer"
              />
              {post.media.length > 1 && (
                <div className="absolute top-6 right-6 bg-black/60 backdrop-blur-xl text-white px-4 py-2 rounded-2xl text-xs font-black tracking-widest">
                  1 / {post.media.length}
                </div>
              )}
            </div>

            {/* Post Content */}
            <div className="p-8">
              <div className="flex items-center justify-between mb-8">
                <div className="flex items-center gap-8">
                  <button className="flex items-center gap-2.5 text-gray-900 hover:text-red-500 transition-all group active:scale-90">
                    <Heart className="w-7 h-7 group-hover:fill-red-500" />
                    <span className="font-black text-lg">{post.likes || 0}</span>
                  </button>
                  <button className="flex items-center gap-2.5 text-gray-900 hover:text-brand-blue transition-all group active:scale-90">
                    <MessageCircle className="w-7 h-7" />
                    <span className="font-black text-lg">Commenter</span>
                  </button>
                  <button className="flex items-center gap-2.5 text-gray-900 hover:text-brand-blue transition-all active:scale-90">
                    <Share2 className="w-7 h-7" />
                  </button>
                </div>
                <div className="flex items-center gap-2 text-gray-400 text-xs font-black uppercase tracking-widest">
                  <Eye className="w-4 h-4" />
                  {post.views || 0} vues
                </div>
              </div>

              <p className="text-gray-800 leading-relaxed text-lg font-medium">
                <span className="font-black mr-2 text-gray-900">{post.provider?.displayName}</span>
                {post.caption}
              </p>

              <div className="mt-8 pt-8 border-t border-gray-50 flex items-center justify-between">
                <div className="flex items-center gap-2 text-gray-500 font-bold text-sm">
                  <MapPin className="w-4 h-4 text-brand-blue" />
                  {post.provider?.city}
                </div>
                <Link 
                  to={`/provider/${post.providerId}`}
                  className="text-brand-blue font-black text-sm hover:text-blue-700 transition-colors flex items-center gap-1 uppercase tracking-widest"
                >
                  Voir le profil complet →
                </Link>
              </div>
            </div>
          </motion.div>
        )) : (
          <div className="bg-white rounded-[3rem] p-24 text-center border border-dashed border-gray-200">
            <div className="w-24 h-24 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-8">
              <Camera className="w-12 h-12 text-gray-300" />
            </div>
            <h3 className="text-2xl font-extrabold text-gray-900 mb-4">Le fil est vide</h3>
            <p className="text-gray-500 font-medium text-lg">Revenez plus tard pour voir les nouvelles réalisations.</p>
          </div>
        )}
      </div>
    </div>
  );
}
