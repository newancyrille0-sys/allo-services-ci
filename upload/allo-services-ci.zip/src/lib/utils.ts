import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatPrice(amount: number, currency: string = 'XOF'): string {
  return new Intl.NumberFormat('fr-CI', {
    style: 'currency',
    currency: currency,
    minimumFractionDigits: 0,
  }).format(amount);
}

export function formatDate(date: Date | string): string {
  return new Intl.DateTimeFormat('fr-CI', {
    day: '2-digit',
    month: 'long',
    year: 'numeric',
  }).format(new Date(date));
}

export function formatPhoneNumber(phone: string): string {
  // Format: 07 XX XX XX XX
  const cleaned = phone.replace(/\D/g, '');
  if (cleaned.length === 10) {
    return cleaned.replace(/(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})/, '$1 $2 $3 $4 $5');
  }
  return phone;
}

export function timeAgo(date: Date | string): string {
  const seconds = Math.floor((new Date().getTime() - new Date(date).getTime()) / 1000);
  if (seconds < 60) return 'À l\'instant';
  if (seconds < 3600) return `${Math.floor(seconds / 60)} min`;
  if (seconds < 86400) return `${Math.floor(seconds / 3600)} h`;
  if (seconds < 604800) return `${Math.floor(seconds / 86400)} j`;
  return formatDate(date);
}

export const CITIES = [
  'Abidjan (Cocody)', 'Abidjan (Plateau)', 'Abidjan (Marcory)', 'Abidjan (Treichville)', 
  'Abidjan (Adjamé)', 'Abidjan (Yopougon)', 'Abidjan (Abobo)', 'Abidjan (Koumassi)', 
  'Abidjan (Port-Bouët)', 'Abidjan (Attécoubé)', 'Abidjan (Songon)', 'Abidjan (Bingerville)',
  'Yamoussoukro', 'Bouaké', 'Daloa', 'San-Pédro', 'Korhogo', 'Man', 'Divo', 'Gagnoa', 
  'Abengourou', 'Bondoukou', 'Agboville', 'Anyama', 'Bassam', 'Bouaflé', 'Boundiali', 
  'Dabou', 'Daoukro', 'Dimbokro', 'Duekoué', 'Ferkessédougou', 'Grand-Bassam', 
  'Grand-Lahou', 'Guiglo', 'Issia', 'Jacqueville', 'Katiola', 'Odienné', 'Séguéla', 
  'Sinfra', 'Soubré', 'Tabou', 'Tiassalé', 'Tingréla', 'Touba', 'Toumodi', 'Vavoua', 'Zuénoula'
];

export const CATEGORIES = [
  { name: 'Ménage & Nettoyage', icon: '🧹' },
  { name: 'Plomberie', icon: '🔧' },
  { name: 'Électricité', icon: '⚡' },
  { name: 'Climatisation', icon: '❄️' },
  { name: 'Peinture', icon: '🎨' },
  { name: 'Menuiserie', icon: '🪵' },
  { name: 'Jardinage', icon: '🌱' },
  { name: 'Déménagement', icon: '🚚' },
  { name: 'Cours & Soutien', icon: '📚' },
  { name: 'Beauté & Bien-être', icon: '💅' },
  { name: 'Informatique', icon: '💻' },
  { name: 'Événementiel', icon: '🎉' }
];

export type SubscriptionTheme = 'free' | 'monthly' | 'premium';

export interface ThemeColors {
  primary: string;
  primaryDark: string;
  secondary: string;
  accent: string;
  badge: string;
  badgeText: string;
  border: string;
  shadow: string;
  gradient: string;
}

export const SUBSCRIPTION_THEMES: Record<SubscriptionTheme, ThemeColors> = {
  free: {
    primary: '#6B7280',
    primaryDark: '#4B5563',
    secondary: '#9CA3AF',
    accent: '#D1D5DB',
    badge: '#E5E7EB',
    badgeText: '#374151',
    border: '1px solid #D1D5DB',
    shadow: '0 1px 3px rgba(0, 0, 0, 0.1)',
    gradient: 'linear-gradient(135deg, #6B7280 0%, #4B5563 100%)',
  },
  monthly: {
    primary: '#2563eb', // brand-blue
    primaryDark: '#1d4ed8',
    secondary: '#60a5fa',
    accent: '#93c5fd',
    badge: '#dbeafe',
    badgeText: '#1e40af',
    border: '2px solid #2563eb',
    shadow: '0 4px 6px rgba(37, 99, 235, 0.2)',
    gradient: 'linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%)',
  },
  premium: {
    primary: '#f97316', // brand-orange
    primaryDark: '#ea580c',
    secondary: '#fb923c',
    accent: '#fdba74',
    badge: '#ffedd5',
    badgeText: '#9a3412',
    border: '3px solid #f97316',
    shadow: '0 10px 25px rgba(249, 115, 22, 0.4)',
    gradient: 'linear-gradient(135deg, #f97316 0%, #ea580c 50%, #fb923c 100%)',
  },
};

export function getThemeColors(subscriptionStatus?: string): ThemeColors {
  if (subscriptionStatus === 'premium') return SUBSCRIPTION_THEMES.premium;
  if (subscriptionStatus === 'monthly') return SUBSCRIPTION_THEMES.monthly;
  return SUBSCRIPTION_THEMES.free;
}

export function getSubscriptionPriority(status?: string): number {
  if (status === 'premium') return 3;
  if (status === 'monthly') return 2;
  return 1;
}
