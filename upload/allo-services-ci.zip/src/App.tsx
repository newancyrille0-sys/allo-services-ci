import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate, Link } from 'react-router-dom';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { ErrorBoundary } from './components/ErrorBoundary';
import Navbar from './components/Navbar';
import Home from './pages/Home';
import Search from './pages/Search';
import Profile from './pages/Profile';
import SocialFeed from './pages/SocialFeed';
import Auth from './pages/Auth';
import Dashboard from './pages/Dashboard';
import Admin from './pages/Admin';

const ProtectedRoute: React.FC<{ children: React.ReactNode; role?: string }> = ({ children, role }) => {
  const { user, profile, loading } = useAuth();

  if (loading) return <div className="min-h-screen flex items-center justify-center">Chargement...</div>;
  if (!user) return <Navigate to="/auth" />;
  if (role && profile?.role !== role) return <Navigate to="/" />;

  return <>{children}</>;
};

export default function App() {
  return (
    <ErrorBoundary>
      <AuthProvider>
        <Router>
          <div className="min-h-screen bg-gray-50 flex flex-col">
            <Navbar />
            <main className="flex-grow">
              <Routes>
                <Route path="/" element={<Home />} />
                <Route path="/search" element={<Search />} />
                <Route path="/provider/:id" element={<Profile />} />
                <Route path="/feed" element={<SocialFeed />} />
                <Route path="/auth" element={<Auth />} />
                <Route 
                  path="/dashboard" 
                  element={
                    <ProtectedRoute>
                      <Dashboard />
                    </ProtectedRoute>
                  } 
                />
                <Route 
                  path="/admin" 
                  element={
                    <ProtectedRoute role="admin">
                      <Admin />
                    </ProtectedRoute>
                  } 
                />
              </Routes>
            </main>
            <footer className="bg-white border-t py-16 px-4">
              <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
                <div className="col-span-1 md:col-span-2">
                  <img 
                    src="https://storage.googleapis.com/gpt-engineer-file-uploads/UwYypcGML3bDONL5eWcQAcyQekD3/07b926e2-bd04-4363-9a73-2f5c4edfcea9?Expires=1774432588&GoogleAccessId=go-api-on-aws%40gpt-engineer-390607.iam.gserviceaccount.com&Signature=Wt1x%2F%2BUWWC58Ngw7aCBIvWV1gzyqmGV5R3aIdjL%2B%2FokkDYul%2BP6kP8gOcgCcLIut%2F4Kd284ne3ciqDacwTR1qGVhVHIN4Jd9XW5gLUW0ZTme5e4SjsXSRyo%2Fi4KGt%2FYt%2BS8L0GvyJWNZ%2Fb4LSsVnBne79%2FwC%2BRETz6RmInxXuqygKh%2BJpsIAfsXBKcBQ8NPXoFQQc%2BxTv4IAhwgeQwXCvjaaOyHkRhoAyeBa9MOyAjbJDGBFcQGf2xysUIfIQ1HAWNZ321142Ql50h1WgRQd30%2BUcKebvH6JdMQCoQZIHBTxvG6%2FHFLZOWGCGqgmN%2BmUaazYrJQNa26sCncVCbydPg%3D%3D" 
                    alt="Allo Services CI" 
                    className="h-16 w-auto mb-6"
                    referrerPolicy="no-referrer"
                  />
                  <p className="text-gray-500 max-w-sm font-medium leading-relaxed">
                    La première marketplace de services en Côte d'Ivoire. Trouvez des professionnels qualifiés pour tous vos besoins du quotidien.
                  </p>
                </div>
                <div>
                  <h4 className="font-bold text-gray-900 mb-6 uppercase tracking-wider text-sm">Plateforme</h4>
                  <ul className="space-y-4 text-gray-500 font-medium">
                    <li><Link to="/search" className="hover:text-brand-blue transition-colors">Trouver un service</Link></li>
                    <li><Link to="/feed" className="hover:text-brand-blue transition-colors">Réalisations</Link></li>
                    <li><Link to="/auth?role=provider" className="hover:text-brand-blue transition-colors">Devenir Prestataire</Link></li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-bold text-gray-900 mb-6 uppercase tracking-wider text-sm">Support</h4>
                  <ul className="space-y-4 text-gray-500 font-medium">
                    <li><Link to="/contact" className="hover:text-brand-blue transition-colors">Contact</Link></li>
                    <li><Link to="/faq" className="hover:text-brand-blue transition-colors">FAQ</Link></li>
                    <li><Link to="/terms" className="hover:text-brand-blue transition-colors">Conditions d'utilisation</Link></li>
                  </ul>
                </div>
              </div>
              <div className="max-w-7xl mx-auto pt-8 border-t border-gray-100 flex flex-col md:flex-row justify-between items-center gap-4 text-gray-400 text-sm font-medium">
                <p>&copy; {new Date().getFullYear()} Allo Services CI. Tous droits réservés.</p>
                <div className="flex gap-6">
                  <a href="#" className="hover:text-brand-blue transition-colors">Facebook</a>
                  <a href="#" className="hover:text-brand-blue transition-colors">Instagram</a>
                  <a href="#" className="hover:text-brand-blue transition-colors">WhatsApp</a>
                </div>
              </div>
            </footer>
          </div>
        </Router>
      </AuthProvider>
    </ErrorBoundary>
  );
}
